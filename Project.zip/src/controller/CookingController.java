package controller;

public class CookingController {
}
