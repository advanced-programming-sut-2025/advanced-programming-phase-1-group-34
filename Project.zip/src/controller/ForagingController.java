package controller;

public class ForagingController {
}
