package controller;

public class AnimalsController {
}
