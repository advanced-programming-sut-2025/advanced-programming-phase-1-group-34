package view.game;

public class TradeView {
}
