package view.game;

public class FarmView {
}
