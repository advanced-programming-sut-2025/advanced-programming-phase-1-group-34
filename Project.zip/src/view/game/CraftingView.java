package view.game;

public class CraftingView {
}
