package view.game;

public class PlayerView {
}
