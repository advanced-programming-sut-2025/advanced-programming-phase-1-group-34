package view.game;

public class InventoryView {
}
