package view.game;

public class AnimalsView {
}
