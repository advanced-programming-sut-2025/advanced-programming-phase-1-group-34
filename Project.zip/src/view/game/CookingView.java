package view.game;

public class CookingView {
}
