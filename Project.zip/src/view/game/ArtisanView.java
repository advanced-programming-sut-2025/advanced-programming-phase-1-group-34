package view.game;

public class ArtisanView {
}
