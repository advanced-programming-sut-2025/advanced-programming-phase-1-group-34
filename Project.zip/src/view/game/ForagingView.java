package view.game;

public class ForagingView {
}
