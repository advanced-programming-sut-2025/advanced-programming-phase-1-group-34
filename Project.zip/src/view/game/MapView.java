package view.game;

public class MapView {
}
