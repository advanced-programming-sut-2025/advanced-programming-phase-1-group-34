package view.game;

public class NPCView {
}
