package view.system;

public class WeatherView {
}
