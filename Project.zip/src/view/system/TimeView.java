package view.system;

public class TimeView {
}
