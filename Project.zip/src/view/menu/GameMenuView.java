package view.menu;

public class GameMenuView {
}
