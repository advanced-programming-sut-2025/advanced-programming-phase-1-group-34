package view.menu;

import controller.LoginMenuController;
import controller.RegisterMenuController;
import model.enums.menuCommands.LoginMenuCommands;
import model.enums.menuCommands.RegisterMenuCommands;

import java.util.Scanner;
import java.util.regex.Matcher;

public class LoginMenuView implements AppMenu {
    private LoginMenuController controller = new LoginMenuController();

    @Override
    public void check(Scanner scanner) {
        String command = scanner.nextLine();
        Matcher matcher;
        if ((matcher = LoginMenuCommands.Login.getMatcher(command)) != null) {
            System.out.println(controller.login(matcher.group("username").trim(), matcher.group("password").trim()));
        } else if ((matcher = LoginMenuCommands.LoginWithSave.getMatcher(command)) != null) {
            System.out.println(controller.loginWithSave(matcher.group("username").trim(), matcher.group("password").trim()));
        } else if ((matcher = LoginMenuCommands.ForgetPassword.getMatcher(command)) != null) {
            System.out.println(controller.forgetPassword(matcher.group("username").trim()));
        } else if ((matcher = LoginMenuCommands.AnswerTheSecurityQuestion.getMatcher(command)) != null) {
            System.out.println(controller.answerTheSecurityQuestion(matcher.group("answer").trim()));
        } else {
            System.out.println("invalid command");
        }
    }
}