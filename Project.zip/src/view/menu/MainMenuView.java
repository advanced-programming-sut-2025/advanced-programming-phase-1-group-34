package view.menu;

public class MainMenuView {
}
