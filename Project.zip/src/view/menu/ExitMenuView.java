package view.menu;

import java.util.Scanner;

public class ExitMenuView implements AppMenu {
    @Override
    public void check(Scanner scanner) {}
}
