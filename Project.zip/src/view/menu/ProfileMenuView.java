package view.menu;

public class ProfileMenuView {
}
