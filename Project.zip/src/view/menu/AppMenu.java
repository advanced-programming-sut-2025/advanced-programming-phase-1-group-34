package view.menu;

import java.util.Scanner;

public interface AppMenu {
    public void check(Scanner scanner);
}
