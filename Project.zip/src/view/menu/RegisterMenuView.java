package view.menu;

import controller.RegisterMenuController;
import model.enums.menuCommands.RegisterMenuCommands;

import java.util.Scanner;
import java.util.regex.Matcher;

public class RegisterMenuView implements AppMenu {
    private RegisterMenuController controller = new RegisterMenuController();

    @Override
    public void check(Scanner scanner) {
        String command = scanner.nextLine();
        Matcher matcher;
        if ((matcher = RegisterMenuCommands.Register.getMatcher(command)) != null) {
            System.out.print(controller.register(scanner, matcher.group("username").trim(), matcher.group("password").trim(), matcher.group("passwordConfirm").trim(), matcher.group("nickname").trim(), matcher.group("email").trim(), matcher.group("gender").trim()));
        } else if ((matcher = RegisterMenuCommands.RegisterWithRandomPassword.getMatcher(command)) != null) {
            System.out.print(controller.registerWithRandomPassword(scanner, matcher.group("username").trim(), matcher.group("nickname").trim(), matcher.group("email").trim(), matcher.group("gender").trim()));
        } else if ((matcher = RegisterMenuCommands.PickQuestion.getMatcher(command)) != null) {
            System.out.print(controller.pickQuestion(Integer.parseInt(matcher.group("questionNumber").trim()), matcher.group("answer").trim(), matcher.group("answerConfirm").trim()));
        } else {
            System.out.println("invalid command");
        }
    }
}
