package model.services;

public class FishingService {
}
