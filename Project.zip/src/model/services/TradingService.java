package model.services;

public class TradingService {
}
