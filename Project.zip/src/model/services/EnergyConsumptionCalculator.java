package model.services;

public class EnergyConsumptionCalculator {
}
