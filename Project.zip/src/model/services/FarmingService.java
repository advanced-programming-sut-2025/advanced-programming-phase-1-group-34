package model.services;

public class FarmingService {
}
