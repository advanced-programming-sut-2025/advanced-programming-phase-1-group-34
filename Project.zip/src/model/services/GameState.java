package model.services;

public class GameState {
}
