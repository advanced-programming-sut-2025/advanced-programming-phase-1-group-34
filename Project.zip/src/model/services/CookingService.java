package model.services;

public class CookingService {
}
