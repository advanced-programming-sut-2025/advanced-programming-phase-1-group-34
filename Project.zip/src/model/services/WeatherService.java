package model.services;

public class WeatherService {
}
