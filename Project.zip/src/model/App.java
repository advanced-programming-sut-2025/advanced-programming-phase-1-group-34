package model;

import model.enums.Menu;
import view.AppView;

import java.util.ArrayList;

public class App {
    private static Menu currentMenu = Menu.RegisterMenu;
    private static User loggedInUser = null;
    public static ArrayList<User> users = new ArrayList<>();
    public static ArrayList<String> securityQuestions = new ArrayList<>();

    static {
        securityQuestions.add("What was the name of your elementary school?");
        securityQuestions.add("What is the name of the city where you were born?");
        securityQuestions.add("What was the name of your first teacher?");
        securityQuestions.add("What is the name of your first pet?");
        securityQuestions.add("What is your favorite movie?");
        securityQuestions.add("In what city did your parents meet?");
        securityQuestions.add("What was the name of the hospital where you were born?");
    }

    public static Menu getCurrentMenu() {
        return currentMenu;
    }
    public static void setCurrentMenu(Menu menu) {
        currentMenu = menu;
    }

    public static User getLoggedInUser() {
        return loggedInUser;
    }
    public static void setLoggedInUser(User user) {
        loggedInUser = user;
    }

    public static User getUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public static String getSecurityQuestionByNumber(int number) {
        number--;
        return securityQuestions.get(number);
    }



}
