package model;

public class Result {
    private String message;

    public Result(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}
