package model.entities;

public class Animal {
}
