package model.entities;

public class FishingSpot {
}
