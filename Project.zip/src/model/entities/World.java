package model.entities;

public class World {
}
