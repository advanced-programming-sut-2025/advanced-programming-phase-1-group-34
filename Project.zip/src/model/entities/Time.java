package model.entities;

public class Time {
}
