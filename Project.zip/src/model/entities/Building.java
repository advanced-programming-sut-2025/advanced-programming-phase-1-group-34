package model.entities;

public class Building {
}
