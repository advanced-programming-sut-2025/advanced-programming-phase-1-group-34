package model.entities;

public class Weather {
}
