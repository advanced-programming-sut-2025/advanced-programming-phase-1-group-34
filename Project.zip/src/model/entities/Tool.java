package model.entities;

public class Tool {
}
