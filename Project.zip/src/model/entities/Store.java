package model.entities;

public class Store {
}
