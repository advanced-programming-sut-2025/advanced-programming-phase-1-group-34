package model.entities;

public class Energy {
}
