package model.entities;

public class Crop {
}
