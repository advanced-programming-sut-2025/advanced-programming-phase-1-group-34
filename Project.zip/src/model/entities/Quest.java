package model.entities;

public class Quest {
}
