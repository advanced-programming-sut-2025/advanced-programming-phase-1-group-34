package model.entities;

public class Farm {
}
