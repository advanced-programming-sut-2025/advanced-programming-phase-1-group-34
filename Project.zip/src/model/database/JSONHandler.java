package model.database;

public class JSONHandler {
}
