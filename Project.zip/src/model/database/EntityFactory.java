package model.database;

public class EntityFactory {
}
