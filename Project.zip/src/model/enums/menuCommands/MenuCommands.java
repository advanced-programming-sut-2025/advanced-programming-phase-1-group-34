package model.enums.menuCommands;

public interface MenuCommands {
}
