package model.enums;

import view.menu.AppMenu;
import view.menu.ExitMenuView;
import view.menu.RegisterMenuView;

import java.util.Scanner;

public enum Menu {
    RegisterMenu (new RegisterMenuView()),
    ExitMenu (new ExitMenuView());

    private AppMenu menu;

    Menu (AppMenu menu) {
        this.menu = menu;
    }

    public void checkCommand(Scanner scanner) {
        this.menu.check(scanner);
    }
}
